package classe

interface Classe {
    val nome: String
    val restricoesDeArmas: String
    val restricoesDeArmaduras: String
    val habilidades: List<String>
}