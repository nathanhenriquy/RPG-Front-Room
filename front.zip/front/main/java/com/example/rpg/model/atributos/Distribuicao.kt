package atributos

enum class Distribuicao {
    CLASSICO, AVENTUREIRO, HEROICO
}
